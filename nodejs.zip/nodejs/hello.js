const test1 = 123
let test2 = 123
const test3 = 123
console.log(test1, test2, test3, test4)

function hello() {
    return "hello world"
}

console.log(hello())